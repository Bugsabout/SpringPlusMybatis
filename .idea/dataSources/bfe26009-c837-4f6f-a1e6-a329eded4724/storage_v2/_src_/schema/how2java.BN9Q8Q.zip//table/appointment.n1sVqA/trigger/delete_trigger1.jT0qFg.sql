create trigger delete_trigger1
  after DELETE
  on appointment
  for each row
  begin
    DELETE  FROM book WHERE book_id = old.book_id;
  end;

